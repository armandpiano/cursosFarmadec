<?php

return [
    'client_id' => '489923546868-mgab31kdr2g2ohlgb095rj0cvlasbse4.apps.googleusercontent.com',
    'client_secret' => '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',
    'redirect_uri' => 'http://localhost/cursosFarmadec/google-callback.php'
];
